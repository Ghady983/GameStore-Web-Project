<?php
session_start();
require_once 'Functions.php' ;
$edit_failed =false;
$username_inuse =false;

if(isset($_SESSION["account"]))
{
 if( 
    isset($_POST['firstname'])
    &&
    isset($_POST['lastname'])
    &&
    isset($_POST['username'])
    &&
    isset($_POST['password'])
    &&
    isset($_POST['confirmpassword'])
    )
    {
        if(checkIfExist($_POST['username'],"Username")){$username_inuse =true;}
    if(
        $_POST['firstname'] !=""
        &&
        $_POST['lastname'] !=""
        &&
        $_POST['username'] !=""
        &&
        $_POST['password'] !=""
        &&
        $_POST['confirmpassword'] !=""
        &&
        $_POST['confirmpassword'] == $_POST['password']
        &&
        !checkIfExist($_POST['username'],"Username")
        )
        {
    require_once "MySQL/db.php";
    $edit_failed =false;
    //Making Edit Account Query

     $query ="
     UPDATE `account` 
     SET 
     `First_Name`='". $_POST['firstname'] ."',

     `Last_Name`='". $_POST['lastname'] ."',

     `Username`='". $_POST['username'] ."',";
     if(isset($_FILES['pfp']) && $_FILES['pfp']['size'] > 0 && isImage(explode(".",$_FILES['pfp']['name'])[1]))
     {
        $ext = explode(".",$_FILES['pfp']['name'])[1];
        $name =generateRandomText() .".". $ext;
        $tmp_name = $_FILES['pfp']['tmp_name'];
        move_uploaded_file($tmp_name,"ProfilePictures/$name");
        $query .= "`Account_Pfp`='". $name ."',";
    
    }
    else
    {
        $query .= "`Account_Pfp`='". $_SESSION["account"][8] ."',"; 
    }

     $query .="`Password`='".MD5($_POST['password'])."' 
     
     WHERE ID = ".$_SESSION["account"][0] ;

     //Sending Edit Account Query
     mysqli_query($connection, $query);
     header("location:Home.php");
    }


    else
    {
        $edit_failed =true;
       
    }
}
}
else
{
    header("location:Home.php");
}




?>
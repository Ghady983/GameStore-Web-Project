<?php
 session_start(); 


$timeforcookie =300;
$token ="";

 if(isset($_SESSION["account"])){header("location:Home.php");  }

else{
 $login_failed =false;



 if( 
    isset($_POST['email']) 
    &&
    isset($_POST['password'])
    )
    {

        if($_POST['email'] !="" && $_POST['password'] !="")
        {
        require_once "MySQL/db.php";
        $query = "SELECT * FROM `account` WHERE Email ='".$_POST['email']."' AND Password ='".MD5($_POST['password'])."'";
        $query_result = mysqli_query($connection, $query);
        if(mysqli_num_rows($query_result) > 0)
        {
            require_once 'Functions.php' ;
            $token = generateRandomText() ;
                
        $_SESSION["account"] = mysqli_fetch_array($query_result);
        $login_failed =false;
        if(isset($_POST['remember-me']))
        {
        setcookie("userId",$_SESSION["account"][0], time() + ($timeforcookie), "/"); // 86400 = 1 day
        setcookie("usertoken",$token, time() + ($timeforcookie), "/");
        }
        setTokenForId($_SESSION["account"][0],$token);
        header("location:Home.php");
        }
        else{ $login_failed = true;}
        }
       else{$login_failed = true;}

    }


}

?>
<?php
session_start();
if(isset($_SESSION["account"]))
{
 if( 
    isset($_POST['wallet']) && $_POST['wallet'] !=""
    )
    {
    require_once "MySQL/db.php";

    //Making Edit Account Query

     $query ="
     UPDATE `account` 
     SET 
     `Wallet`='". $_POST['wallet'] ."'

     WHERE ID = ".$_SESSION["account"][0] ;

     //Sending Edit Account Query
     mysqli_query($connection, $query);
     header("location:Home.php");
    }
    else
    {
        echo "no";
       
    }
}
else
{
    header("location:Home.php");
}




?>
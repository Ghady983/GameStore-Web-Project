<?php
require_once 'Functions.php' ;
 session_start(); 
$addgamefailed=false;
 if(!isset($_SESSION["account"])){header("location:Home.php");  }
 else if(!checkIsAdmin()){header("location:Home.php");}

 else{

 if( 
    isset($_POST['gametitle'])
    &&
    isset($_POST['gameprice'])
   
    )
    {
        if(
            $_POST['gametitle'] !=""
            &&
            $_POST['gameprice'] !=""
            )
            {
    require_once "MySQL/db.php";
    $reg_failed =false;
    //Making Register Query
     $query = "
     INSERT INTO `game`(`Game_Title`, `Game_Price`";
     if(isset($_FILES['gposter']) && $_FILES['gposter']['size'] > 0  && isImage(explode(".",$_FILES['gposter']['name'])[1]) )
     {
        $query .= ", `Game_Poster`";
    }
    if(isset($_FILES['gwall']) && $_FILES['gwall']['size'] > 0 && isImage(explode(".",$_FILES['gwall']['name'])[1]) )
    {
       $query .= ", `Game_wallpaper`";
   }
     $query .=")VALUES(";
     $query .= "'".$_POST['gametitle']."',";
     $query .= "'".$_POST['gameprice']."'"; 
     if(isset($_FILES['gposter']) && $_FILES['gposter']['size'] > 0 && isImage(explode(".",$_FILES['gposter']['name'])[1]))
     {
        
        $ext = explode(".",$_FILES['gposter']['name'])[1];
        $name =generateRandomText() .".". $ext;
        $tmp_name = $_FILES['gposter']['tmp_name'];
        move_uploaded_file($tmp_name,"GameLogos/$name");
        $query .=",";
        $query .= "'$name'";   
     }
     if(isset($_FILES['gwall']) && $_FILES['gwall']['size'] > 0 && isImage(explode(".",$_FILES['gwall']['name'])[1]))
     {
        $ext = explode(".",$_FILES['gwall']['name'])[1];
        $name =generateRandomText() .".". $ext;
        $tmp_name = $_FILES['gwall']['tmp_name'];
        move_uploaded_file($tmp_name,"GameWallpapers/$name");
        $query .=",";
        $query .= "'$name'";   
     }

     $query .= ")";

     //Sending Register Query
     mysqli_query($connection, $query);        
    }
    else{$addgamefailed=true;}

    }
}


?>
<?php
require_once 'Functions.php' ;
 session_start(); 


 if(isset($_SESSION["account"])){header("location:Home.php");  }
 else{

$reg_failed =false;
$email_inuse =false;
$username_inuse =false;
 if( 
    isset($_POST['firstname'])
    &&
    isset($_POST['lastname'])
    &&
    isset($_POST['email'])
    &&
    isset($_POST['username'])
    &&
    isset($_POST['password'])
    &&
    isset($_POST['confirmpassword'])
   
    )
    {
        if(checkIfExist($_POST['username'],"Username")){$username_inuse =true;}
        if(checkIfExist($_POST['email'],"Email")){$email_inuse =true;}
        if(
            $_POST['firstname'] !=""
            &&
            $_POST['lastname'] !=""
            &&
            $_POST['email'] !=""
            &&
            $_POST['username'] !=""
            &&
            $_POST['password'] !=""
            &&
            $_POST['confirmpassword'] !=""
            &&
            $_POST['confirmpassword'] == $_POST['password']
            &&
            !checkIfExist($_POST['email'],"Email")
            &&
            !checkIfExist($_POST['username'],"Username")
            )
            {
    require_once "MySQL/db.php";
    $reg_failed =false;
    //Making Register Query
     $query = "
     INSERT INTO `account`(`First_Name`, `Last_Name`, `Email`, `Username`,`Password`)
     VALUES(";
     $query .= "'".$_POST['firstname']."',";
     $query .= "'".$_POST['lastname']."',";
     $query .= "'".$_POST['email']."',";
     $query .= "'".$_POST['username']."',";
     $query .= "'".MD5($_POST['password'])."'"; 
     $query .= ")";

     //Sending Register Query
     mysqli_query($connection, $query);
     header("location:LogIn.php");          
    }
    else
    {
        $reg_failed =true;
       
    }

    }
}


?>
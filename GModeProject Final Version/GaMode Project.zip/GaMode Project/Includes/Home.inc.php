<?php
$logged_in=false;
if(isset($_SESSION["account"])){$logged_in =true;}
else{$logged_in =false;}
//Browse_Games.php?bg_search=

if(isset($_GET['bg_search'])){$search_query =$_GET['bg_search'];header("location:Browse_Games.php?bg_search=$search_query");}
?>
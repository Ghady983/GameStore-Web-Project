<?php
$found= 0;
if( 
    isset($_GET['bg_search']) && $_GET['bg_search']!=""
    )
{
    $search_text = $_GET['bg_search'];
    require_once "MySQL/db.php";
    $query = "SELECT * FROM `game` WHERE Game_Title LIKE '%".$search_text."%'";
    $query_result = mysqli_query($connection, $query);
    if(mysqli_num_rows($query_result) > 0)
    {
        $found = 1;
    }
    else{$found= 2;}



}
else if(isset($_GET['categ_id']) && $_GET['categ_id']!="")
{
    require_once "MySQL/db.php";
    $query ="SELECT Game_ID,Game_Title,Game_Price,Game_Poster,Rating,Game_wallpaper FROM `category` c , `game` g ,`category-game` cg WHERE cg.Game_cg_ID = g.Game_ID AND cg.Category_cg_ID='".$_GET["categ_id"] ."' AND cg.Category_cg_ID=c.Category_ID;";
    $query_result = mysqli_query($connection, $query);
    if(mysqli_num_rows($query_result) > 0)
    {  
        $found = 4;       
    
    }
    else{$found =3;}
}












?>
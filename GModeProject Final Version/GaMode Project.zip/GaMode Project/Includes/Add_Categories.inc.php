<?php
 session_start(); 
 require_once 'Functions.php' ;

 if(!isset($_SESSION["account"])){header("location:Home.php");  }
 else if(!checkIsAdmin()){header("location:Home.php");}
 else{
  $already_exists =false;
 $cat_already_exists ="";
 if(isset($_GET["id"]))
 {
    $game_id = $_GET["id"];

 
if(count($_GET) >0){


for($i =1;$i<=4;$i++)
{

if(isset($_GET[$i]))
{
if( checkIfCategoryForGameAlreadyExists($game_id,$i)){ $already_exists =true; $cat_already_exists .= accessCategory($i) ." &nbsp ";}
    else {
        
        $already_exists =false;
        require_once "MySQL/db.php";
        $query = "INSERT INTO `category-game` (`Game_cg_ID`, `Category_cg_ID`) VALUES ('$game_id', '$i');";
        $query_result = mysqli_query($connection, $query);    
         }

}

}
    
}
}
else{ header("location:Home.php");}

}


?>
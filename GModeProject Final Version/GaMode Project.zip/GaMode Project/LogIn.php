<?php require_once 'Includes/LogIn.inc.php' ; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-reg-body">
<?php require_once "Reg-Log-Header.php"; ?>


    <!-- Reg form -->
    <div class="reg-form">
    <h1>Login</h1>
    <div class="line-2"></div>
    <form action="#" method="post">

        <img src="Icons/mail-icon.png" class="sub-logo"><label><input type="email" id="email" name="email" placeholder="E-mail"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/key-icon.png" class="sub-logo"><label> <input type="password" id="password" name="password" placeholder="Password"></label>
        <div class="line-1"></div>
        <br><br>
        <span class="rem-me">Remember me &nbsp<input type="checkbox" name="remember-me"></span>
        <br><br>
        Yet to join? <a href="SignUp.php">Sign Up</a>
        <br><br> 

        <div class="login-failed">
            <?php if($login_failed ==true){echo "Login Failed";}?>
        </div>

        <br>     
        <button type="submit" class="login-submit"> Login </button>
      
     </form>
    </div>
 </body>
</head>
</html>

<?php require_once 'Functions.php' ; 
 require_once 'Includes/Browse_Games.inc.php' ; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Game</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />

</head>

	<!-- CSS -->
    <style type="text/css"></style>
<body class="web-body">

<div class="wrapper-bgame" id="Side-Bar">
        <!--Top menu -->
		
        <div class="sidebar-bgame">
        <a href="Home.php" class="home">&nbsp Back to Home</a>    
        <div class="space-div"></div>
        <form action="#" method="GET">
            <h1> &nbsp Search <input type='text' class='search-bar' id="bg_search" name="bg_search"></h1>
			<hr>

            &nbsp <input type="submit" value="Search" class="bgame-search"/>
        </form>
        </div>

    </div>

        <div class='bgame-container'>
    <h1 class='bgame-searchtext'><?php
     if($found == 1){echo"&nbsp Search Results For : $search_text";}
     else if($found == 2){echo"&nbsp No Results For : $search_text";}
     else if($found == 3){echo"&nbsp No Results";} 
     else if($found == 4){echo accessCategory($_GET['categ_id']). " Games";}
     else{echo "&nbsp Browse Games";}
     ?></h1>
    <div class="space-div"></div>
		<table class="bgame-table">
    
        <?php
        if($found == 1)
        {
            while($result = mysqli_fetch_array($query_result))
            {createBGame($result[1],$result[2],$result[3],$result[0],$result[5]);}
        }
        else if($found == 0){bGameRandomSelect();}

        if($found == 4)
        {
            while($result = mysqli_fetch_array($query_result))
            {createBGame($result[1],$result[2],$result[3],$result[0],$result[5]);}
        }
        

        ?>

                

		</table>

        </div>
</body>
</html>
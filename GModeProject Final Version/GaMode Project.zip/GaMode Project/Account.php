<?php 
require_once 'Includes/Account.inc.php' ;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Account</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-reg-body">

<?php require_once "Reg-Log-Header.php"; ?> 


    <!-- Reg form -->
    <div class="reg-form">
    <h1>Edit Account</h1>
    <div class="line-2"></div>
    <form action="#" method="post" enctype="multipart/form-data">
        <label><input type="file" id="pfp" name="pfp"></label> 
        <br><br>
        <img src="Icons/user-icon.png" class="sub-logo"><label><input type="text" id="firstname" name="firstname" placeholder="First Name : <?php echo $_SESSION["account"][1] ?>"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/user-icon.png" class="sub-logo"><label><input type="text" id="lastname" name="lastname" placeholder="Last name : <?php echo $_SESSION["account"][2] ?>"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/user-icon.png" class="sub-logo"><label><input type="text" id="username" name="username" placeholder="Username : <?php echo $_SESSION["account"][4] ?>"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/key-icon.png" class="sub-logo"><label> <input type="password" id="password" name="password" placeholder="Password"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/key-icon.png" class="sub-logo"><label> <input type="password" id="confirmpassword" name="confirmpassword" placeholder="Confirm Password"></label>
        <div class="line-1"></div>
        <br><br>

        <div class="login-failed">
            <?php if($edit_failed ==true){echo "Edit Account Failed";}?>
            <br>
            <?php if($username_inuse ==true){echo "Username Already in Use";}?>
        </div>
        <br><br>
        <button type="submit" class="sign-up-submit"> Apply </button>
        
     </form>
     <span class="wallet-changer-link"><a href="WalletChanger.php">Wallet Changer (For Testing Purposes)</a></span>
    </div>
 </body>
</head>
</html>

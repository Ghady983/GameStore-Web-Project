<?php  

require_once 'Functions.php' ;
resetSession();

require_once 'Includes/Home.inc.php' ;


?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
	<title>Home</title>
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-body">

<div class="wrapper" >
        <!--Top menu -->
		
        <div class="sidebar" id="Side-Bar">
		<button onclick="hideSideBar()" class="close_p_desc" title="Close Profile Description"><img src="Icons/back-icon.png"></button>
		<a href="Library.php" class="Library-sidebar" title="Game Library"><img src="Icons/game-library-icon.png"></a>
		   <div class="profile">
		   <a href="#"  class="profile-home"><?php if($logged_in){echo "<img src='ProfilePictures/".$_SESSION["account"][8]."'>";} else {echo "<img src='ProfilePictures/base_pfp.jpg'>";}?></a>
                <h1><?php if($logged_in){echo $_SESSION["account"][1] . " " .$_SESSION["account"][2] ;} else {echo "User";}?></h1>
				<h4><?php if($logged_in){echo "@".$_SESSION["account"][4];} else {echo "@";}?></h4>
				<a href="Account.php"><p>Edit Account</p></a>
				<hr>
				<h4>Wallet $<?php if($logged_in){echo $_SESSION["account"][5];} else {echo -1;}?></h4>
				<a href="WalletChanger.php"><p>Edit Wallet</p></a>
			</div>
			<div class="logout-sidebar">
			<a href='Logout.php' class='log-out'><h2>Logout</h2></a>
			</div>
        </div>

    </div>
    	<!-- Top Header -->
    <div class="top-header">
		<div class="reg">
			<?php
			if(!$logged_in)
			{
				echo "
			<a href='LogIn.php' class='login'>Login</a>
			  |  
			<a href='SignUp.php' class='sign-up'>SignUp</a>
			";
			}
			else if(checkIsAdmin())
			{
				echo "
				<a href='AddGames.php' class='login'>Add Games</a>
				";
			}


			?>
		</div>
		<header>
			<nav>
				<div class="logo">
				<img src= "Icons/company_logo.png" class = "website-logo">
				</div>
				<ul >
					
					<span id="basics-header">
					<li><a href="#Home" class="home">Home</a></li>			
					<li><a href="Browse_Games.php" class="bio">Browse Games</a></li>
					<li><button class= "upper-tab-but"onclick="SearchBar_Change()" title="Search"><img src="Icons/search-icon.png"></button></li>
				    </span>
					
					
					<?php
					if($logged_in)
					{
                   echo" <li><button class='sidebar-button'onclick='showSideBar()' title='Open Profile Description'><img src='ProfilePictures/".$_SESSION["account"][8]."'></button></li>";
					}
				?>
					</ul>
			</nav>
		</header>
	</div>

	

	<script src="JsCode.js"></script>


	<!-- Header -->

<div class="header-cont" id="Home" >

	<section class="paralax">
		<img src="HeadPoster/HeadPoster.jpg">
		<div id="header-text" class="header-text"  onmouseover="translateFunctionUp()"  >
		<h1>Welcome <?php if($logged_in){echo $_SESSION["account"][1];} else {echo "User";}?> </h1>
		<h2>To <?php echo $sitename ; ?></h2>
		</div>
	<img src="HeadPoster/HeadPoster Front.png">
	</section>

</div>

<!-- Game Browser -->

<div class="game-container" id="BGame">
	<hr>
	<div class="title-games"><h1>Buy Video Games With Cheapest Prices On <?php echo $sitename ; ?>!</h1></div>
	<hr>
<!-- Top 5 Games -->
	<div class="top-5-games">
	<h2>Top 5 Games</h2>
		<br>
	<div class="line-3"></div>
	<table class="game_table">
		<tr>
<?php selectByHighestRating(5);?>

		</tr>
		
		
	</table>
 	<hr>
 	<p class="game-section-desc">These are the most popular products . See what video games and DLCs other players love best. There's, without a doubt, a reason why they are in the TOP 5, so maybe you should give them a try too?</p>
 	<hr>
	</div>

	<!-- Category Browse -->
	<div class="browse-by-categ">
		<h2>Browse Category</h2>
		<br>
	<div class="line-3"></div>

	<!-- Space Div -->
<div class="space-div"></div>

		<table class="categ-table">
			
				<tr>
				<?php createGenre("Action",1,"action.png") ; ?>
				</tr>

				<tr>
				<?php createGenre("Simulation",2,"simulation.png") ; ?>
				</tr>

				<tr>
				<?php createGenre("Open-World",4,"openworld.png") ; ?>
				</tr>
				<tr>
				<?php createGenre("Adventure",3,"adventure.png") ; ?>
				</tr>
			
		</table>

		<hr>
		<p class="game-section-desc">In this Section, you can browse by Category to find your favorite Games.</p>
		<hr>

	</div>

	<!-- Games Under $5 -->
	<div class="games-under-5">
		<h2>Games Under $5</h2>
			<br>
		<div class="line-3"></div>
		<table class="game_table">
			<tr>
			<?php selectByUnder5(5);?>
			</tr>
			
			
		</table>
		 <hr>
		 <p class="game-section-desc">Best games under $5? We have it all! From AAA games to top indie titles, all for less than $5. Enjoy a remarkable gaming experience at the best price. Search through the finest offers and save money.</p>
		 <hr>
		</div>
    
		
</div>

<!-- Space Div -->
<div class="space-div"></div>

<!-- Footer -->
<div class="footer">
<hr>
<div class="footer-sign">
<img src= "Icons/company_footer.png">
<p class="footer-sign-text">© <?php echo $sitename ; ?>. All rights reserved. All trademarks and registered trademarks are the property of their respective owners.</p>
</div>
<hr>
</div>
</body>



</html>
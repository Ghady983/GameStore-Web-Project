<?php
session_start();
if(isset($_SESSION["account"]))
{
    setcookie("userId","", time() - 1, "/");
    setcookie("usertoken","", time() - 1, "/");
    unset($_SESSION["account"]);
}
header("location:Home.php");

?>
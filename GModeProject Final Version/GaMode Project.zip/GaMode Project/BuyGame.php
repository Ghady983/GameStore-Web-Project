<?php
    session_start();
if(isset($_GET["gid"]) && isset($_SESSION["account"]))
{
    $alreadypurchased = false;
    $gid = $_GET["gid"];
    require_once 'Functions.php' ; 
    if((checkPriceForGame($gid) <= checkAccountWallet($_SESSION["account"][0])) && checkIfGameAlreadyInLibrary($_SESSION["account"][0],$gid) == false)
    {
        echo "can purchase";
        alterWallet($_SESSION["account"][0],(checkAccountWallet($_SESSION["account"][0]) - checkPriceForGame($gid)) );
        purchaseGame($_SESSION["account"][0],$gid);

    }
    else
    {
        header("location:FailedPurchase.php");
    }
}


else
{
header("location:FailedPurchase.php");
}



?>
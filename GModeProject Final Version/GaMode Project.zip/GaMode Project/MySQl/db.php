<?php
//Config
$config = [
    "MYSQL_HOST" => "localhost" ,
    "MYSQL_DB" => "gamestore" ,
    "MYSQL_USER" => "Admin",
    "MYSQL_PASS" => "12345678"
    
    ];

//Make Connection
global $connection;
$connection = new mysqli($config["MYSQL_HOST"],
                         $config["MYSQL_USER"],
                         $config["MYSQL_PASS"],
                         $config["MYSQL_DB"]
                        );
                        

// Check Connection
if($connection->connect_error)
{
    die("Connection failed: ". $connection->connect_error);
}

<?php 
require_once 'Includes/WalletChanger.inc.php' ;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Wallet</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-reg-body">

<?php require_once "Reg-Log-Header.php"; ?> 


    <!-- Reg form -->
    <div class="reg-form">
    <h1>Edit Wallet</h1>
    <div class="line-2"></div>
    <form action="#" method="post">
        
        <img src="Icons/wallet-icon.png" class="sub-logo"><label><input type="text" id="wallet" name="wallet" placeholder="Wallet: <?php echo "$".$_SESSION["account"][5] ?>"></label>
        <div class="line-1"></div>
        <br><br>
        <button type="submit" class="sign-up-submit"> Change Wallet </button>
     </form>
    </div>
 </body>
</head>
</html>

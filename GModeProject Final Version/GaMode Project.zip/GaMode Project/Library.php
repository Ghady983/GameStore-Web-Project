<?php  

require_once 'Functions.php' ;
resetSession();

require_once 'Includes/Home.inc.php' ;

?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
	<title>Library</title>
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-body">

<?php require_once "Reg-Log-Header.php"; ?>

	<script src="JsCode.js"></script>


	<!-- Header -->

<div class="header-cont" id="Home" >

	<section class="paralax">
		<img  src="HeadPoster/HeadPoster.jpg">
		<div id="header-text" class="header-text"  onmouseover="translateFunctionUp()"  >
		<div class="space-div"></div>
	<div id="lib_img" class="lib_pfp"><?php if($logged_in){echo "<img src='ProfilePictures/".$_SESSION["account"][8]."'>";} else {echo "<img src='ProfilePictures/base_pfp.jpg'>";}?></div>
		<h1>Welcome <?php if($logged_in){echo $_SESSION["account"][1];} else {echo "User";header("location:Home.php");}?> </h1>
		<h2>To Your Library</h2>
		</div>
	<img src="HeadPoster/HeadPoster Front.png">
	</section>

</div>

<!-- Game Browser -->

<div class="game-container" id="BGame">
	<hr>
	<div class="title-games"><h1>Your Library</h1></div>
	<hr>
	<table class="game_lib_table">

<?php selectFromLibrary($_SESSION["account"][0]);?>


		
		
	</table>
	<hr>
	</div>
  
		
</div>

</body>



</html>
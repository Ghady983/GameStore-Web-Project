let searchind=0;
let html0 = document.getElementById("basics-header").innerHTML;

//onload
window.onload=hideSideBar();



function SearchBar_Change()
{ 

let html1="<li><form action='#'' method='GET'><input type='text' class='search-bar' id='bg_search' name='bg_search'></li> <li><button class= 'upper-tab-but'onclick='SearchBar_Change()' title='Cancel Search'><img src='Icons/X-icon.png'></button></form></li>";
let html="";
switch(searchind)
{
case 0: searchind=1; html=html1;break;
case 1: searchind=0;html=html0;break;
}
document.getElementById("basics-header").innerHTML = html;
}

function translateFunctionUp() {
    document.getElementById("header-text").style.transform="translateY(-13rem)";
    
    document.getElementById("header-text").style.transition=" all 2s" ;
    if(document.getElementById("lib_img"))
    {
      document.getElementById("lib_img").style.transform="translateY(-13rem)";
      document.getElementById("lib_img").style.transition=" all 2s" ;
    }
  //  setTimeout(translateFunctionDown, 3000);
    
    }
   /* function translateFunctionDown() {
        document.getElementById("header-text").style.transform="translateY(10rem)";
        document.getElementById("header-text").style.transition=" all 2s" 
        } */


function hideSideBar()
{
    document.getElementById("Side-Bar").style.width = "0rem";
    setTimeout(sideBarNoDisplay, 500);
  

  
}

function sideBarNoDisplay(){document.getElementById("Side-Bar").style.display = "none";}

function showSideBar()
{
  document.getElementById("Side-Bar").style.display = "";
  setTimeout(sideBarDisplay, 0);

}

function sideBarDisplay()
{


document.getElementById("Side-Bar").style.width = "20rem";
}
function debuging()
{
console.log("hello");
}



<?php

require "MySQL/db.php";
$sitename="GMode";



function resetSession()
{
    session_start();
 
    //check cookie
    if(isset($_COOKIE["userId"]) && !isset($_SESSION["account"]))
    {
      if(isset($_COOKIE["usertoken"]))
      {
      if(checkIfTokenIsCorrect($_COOKIE["userId"],$_COOKIE["usertoken"]))
      {loginFromId($_COOKIE["userId"]);}
      else
      {
        setcookie("userId","", time() - 1, "/");
        setcookie("usertoken","", time() - 1, "/");
      }
      }
 
       
    }

    if(isset($_SESSION["account"]))
    {
      global $connection;
        $id =$_SESSION["account"][0];

        $query = "SELECT * FROM `account` WHERE ID ='".$id."'";
        $query_result = mysqli_query($connection, $query);
        if(mysqli_num_rows($query_result) > 0)
        {
        $_SESSION["account"] = mysqli_fetch_array($query_result);

        }
    }
}


function checkIsAdmin()
{
  if(isset($_SESSION["account"]))
  {
  if($_SESSION["account"][7] == 1 ){return true;}else{return false;}
  }
}

function createGameBox($pname, $price,$poster,$id,$wall) {
    echo
    "
    <td>
    <a href='Game_Page.php?title=$pname&price=$price&id=$id&poster=$wall' class='game-hyperlink'>
          <div class='product'>
					<div class='product-image'> <img src= 'GameLogos/$poster' class = 'product-logo'> </div>
					<div class='product-description'>
			
					<div class='product-name'>
			
					<h3>$pname</h3>
					<div class='product-paid_icon'>
			
					<img src='Icons/company_logo_small.png' title='Provided by GMode'>
			
					</div>
			
					</div>
			
					<div class='product-price'>
			
					<p class='price-text'> $$price </p>
			
					</div>
			
					</div>
			
				</div>
  </a>
  </td>
";
  } 

  function createGenre($gname,$genre_id,$g_logo) 
  {
    echo"<td>
    <a href='Browse_Games.php?categ_id=$genre_id' class='game-hyperlink'>
    <img src='GenreLogos/$g_logo' class='categ-img'>
    &nbsp;
    <h3 class='categ-text'>$gname</h3>
    </a>
    </td>";
  }
  function createBGame($bgname,$bgprice,$bgposter,$bgid,$bgwall) 
  {
    echo"	<tr>

    <td>
    <a href='Game_Page.php?title=$bgname&price=$bgprice&id=$bgid&poster=$bgwall' class='game-hyperlink'>
            <img src='GameLogos/$bgposter' class='bgame-img'>
            &nbsp;
            <h3 class='bgame-text'>$bgname</h3>
            <h4 class='bgame-gprice'>$$bgprice</h4>	
    </a>
    </td>

    </tr>
            ";
  }

function checkIfExist($input,$text)
{
  $restrictions = array("Email", "Username");
  
if (in_array($text, $restrictions))
{


  global $connection;
        $query = "SELECT ".$text." FROM `account` WHERE ".$text." ='".$input."'";   
        $query_result = mysqli_query($connection, $query);    
        if(mysqli_num_rows($query_result) > 0)
        {         
          return true;
        }
        else{return false;}
}
else{return true;}
}

function selectByHighestRating($limit)
{
  global $connection;
        $query = "SELECT * FROM game ORDER BY Rating DESC LIMIT $limit";   
        $query_result = mysqli_query($connection, $query);    
        if(mysqli_num_rows($query_result) > 0)
        {         
       // $result = mysqli_fetch_array($query_result);
        while($result = mysqli_fetch_array($query_result))
        {createGameBox($result[1],$result[2],$result[3],$result[0],$result[5]);}
        
        }

}

function selectByUnder5($limit)
{
  global $connection;
        $query = "SELECT * FROM `game` WHERE Game_Price<= 5 LIMIT $limit";   
        $query_result = mysqli_query($connection, $query);    
        if(mysqli_num_rows($query_result) > 0)
        {         
       // $result = mysqli_fetch_array($query_result);
        while($result = mysqli_fetch_array($query_result))
        {createGameBox($result[1],$result[2],$result[3],$result[0],$result[5]);}
        
        }

}

function bGameRandomSelect()
{
  global $connection;
  $query = "SELECT * FROM `game`";   
  $query_result = mysqli_query($connection, $query);    
  if(mysqli_num_rows($query_result) > 0)
  {         
  while($result = mysqli_fetch_array($query_result))
  {createBGame($result[1],$result[2],$result[3],$result[0],$result[5]);}
  
  }
}

function checkCategoryForGame($id)
{
global $connection;
$query ="SELECT Category_Name FROM `category` c , `game` g ,`category-game` cg WHERE cg.Game_cg_ID = g.Game_ID AND cg.Game_cg_ID=$id AND cg.Category_cg_ID=c.Category_ID;";
$query_result = mysqli_query($connection, $query);    
if(mysqli_num_rows($query_result) > 0)
{         
while($result = mysqli_fetch_array($query_result))
{echo $result[0] ." &nbsp";}
}

}

function checkIfCategoryForGameAlreadyExists($gameid,$catid)
{
  global $connection;
  $query ="SELECT * FROM `category-game` WHERE Game_cg_ID='$gameid' AND Category_cg_ID='$catid'";
  $query_result = mysqli_query($connection, $query);        
return mysqli_num_rows($query_result) > 0;

}

function accessCategory($category_id)
{
  global $connection;
$query ="SELECT * FROM `category` WHERE Category_ID='$category_id'";
$query_result = mysqli_query($connection, $query);    
if(mysqli_num_rows($query_result) > 0)
{         
return mysqli_fetch_array($query_result)[1];
}
else{return "category";}
}

function selectByCategory($cid)
{
  global $connection;
  $query ="SELECT Game_ID,Game_Title,Game_Price,Game_Poster,Rating,Game_wallpaper FROM `category` c , `game` g ,`category-game` cg WHERE cg.Game_cg_ID = g.Game_ID AND cg.Category_cg_ID=$cid AND cg.Category_cg_ID=c.Category_ID;";
  $query_result = mysqli_query($connection, $query);
  if(mysqli_num_rows($query_result) > 0)
  {         
  while($result = mysqli_fetch_array($query_result))
  {createBGame($result[1],$result[2],$result[3],$result[0],$result[5]);}
  
  }
}

function generateRandomText()
{
return hash('ripemd160', time() * rand() * 9912304034);
}
function isImage($image){
    $imgExtArr = ['jpg', 'jpeg', 'png'];
    if(in_array($image, $imgExtArr)){
        return true;
    }
    return false;
  }

  function createLibGameBox($pname, $price,$poster,$id,$wall) {
    echo
    "
    <td>
        <a href='Game_Page.php?title=$pname&price=$price&id=$id&poster=$wall' class='game-hyperlink'>
              <div class='product_lib'>
                <div class='product-image'> <img src= 'Icons/company_banner.jpg' class = 'company_label_banner'> </div>
                        <div class='product-image'> <img src= 'GameLogos/$poster' class = 'product-logo'> </div>
                        <div class='product-description'>
                
                        <div class='product-name'>
                
                        <h3>$pname</h3>
                      
                
                        </div>
                
                        </div>
                
                    </div>
      </a>
      </td>
";
  } 

  function selectFromLibrary($acc_id)
{
  global $connection;
        $query = "SELECT Game_ID,Game_Title,Game_Price,Game_Poster,Rating,Game_wallpaper FROM `libraries` l , `game` g  WHERE l.Game_lib_ID = g.Game_ID AND l.Account_lib_id=$acc_id;";   
        $query_result = mysqli_query($connection, $query);
        $row_counter=0;
        if(mysqli_num_rows($query_result) > 0)
        {   
          echo "<tr class ='library_row'>";      
        while($result = mysqli_fetch_array($query_result))
        {
          
          if($row_counter%5 == 0){echo "</tr><tr class ='library_row'>";$row_counter=0;}
          createLibGameBox($result[1],$result[2],$result[3],$result[0],$result[5]);
          $row_counter++;
        }
        }
        else{echo"<div class='title-games'><h4>You Own No Games</h4></div>";}

}

function checkIfGameAlreadyInLibrary($acc_id,$game_id)
{
  global $connection;
        $query = "SELECT Game_ID,Game_Title,Game_Price,Game_Poster,Rating,Game_wallpaper FROM `libraries` l , `game` g  WHERE l.Game_lib_ID = g.Game_ID AND l.Account_lib_id=$acc_id AND l.Game_lib_ID = $game_id;";   
        $query_result = mysqli_query($connection, $query);
        if(mysqli_num_rows($query_result) > 0)
        {   
          return true;
        }
        else{return false;}

}
function checkPriceForGame($gid)
{
  
  global $connection;
  $query = "SELECT Game_Price FROM `game` WHERE Game_ID = $gid";   
  $query_result = mysqli_query($connection, $query);    
  if(mysqli_num_rows($query_result) > 0)
  {         
  $result = mysqli_fetch_array($query_result);
    return $result[0];
  }
  else{header("location:FailedPurchase.php");}
}
function checkAccountWallet($accid)
{
  global $connection;
  $query = "SELECT Wallet FROM `account` WHERE ID = $accid;";   
  $query_result = mysqli_query($connection, $query);    
  if(mysqli_num_rows($query_result) > 0)
  {         
  $result = mysqli_fetch_array($query_result);
    return $result[0];
  }
  else{header("location:FailedPurchase.php");}
  
}
function alterWallet($accid,$wallet)
{
  global $connection;
  $query ="UPDATE `account` SET `Wallet`='$wallet'WHERE ID = $accid ";
  mysqli_query($connection, $query);
  if(mysqli_affected_rows($connection) >0 )
  {
    echo "Changed Wallet";
  }
  else{header("location:FailedPurchase.php");}
}
function purchaseGame($accid,$gid)
{
  global $connection;
  $query ="INSERT INTO `libraries`(`Game_lib_id`, `Account_lib_id`) VALUES ('$gid','$accid')";
  mysqli_query($connection, $query);
  if(mysqli_affected_rows($connection) >0 )
  {
    header("location:Library.php");
  }
  else{header("location:FailedPurchase.php");}
 
}
function loginFromId($id)
{
  global $connection;
  $query = "SELECT * FROM `account` WHERE ID = $id;";
  $query_result = mysqli_query($connection, $query);
  if(mysqli_num_rows($query_result) > 0)
  {

  $_SESSION["account"] = mysqli_fetch_array($query_result);

  }
  else{header("location:LogIn.php");}
}

function setTokenForId($id,$tokenval)
{
  global $connection;
  $query = "UPDATE `account` SET `Token`='$tokenval' WHERE Id = $id";
  $query_result = mysqli_query($connection, $query);
  if(mysqli_affected_rows($connection) >0 )
  { return true; }
  else{ return false; }
}

function checkIfTokenIsCorrect($userId,$token)
{

  global $connection;
  $query = "SELECT * FROM `account` WHERE ID= '$userId' AND Token = '$token' ";
  $query_result = mysqli_query($connection, $query);
  if(mysqli_num_rows($query_result) > 0)
  { return true; }
  else{ return false; }
  
}
?>
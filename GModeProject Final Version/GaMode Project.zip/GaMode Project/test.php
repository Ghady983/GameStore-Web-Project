
<!DOCTYPE html>
<html>
<head>
    <title>Add Categories</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-reg-body">

<?php require_once "Reg-Log-Header.php"; ?> 


    <!-- Reg form -->
    <div class="reg-form">
    <h1>Add Categories</h1>
    <div class="line-2"></div>
    <form action="#" method="post" enctype="multipart/form-data">
    <input type='checkbox' title='Action'><input type='checkbox' title='Simulation'>
        <br><br>
    <input type='checkbox' title='Adventure'><input type='checkbox' title='OpenWorld'>
        <br><br>

        <button type="submit" class="sign-up-submit"> Add Categories</button>
     </form>
    </div>
 </body>
</head>
</html>

<?php require_once 'Includes/AddGames.inc.php' ?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Game</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-reg-body">

<?php require_once "Reg-Log-Header.php"; ?> 


    <!-- Reg form -->
    <div class="reg-form">
    <h1>Add Game</h1>
    <div class="line-2"></div>
    <form action="#" method="post" enctype="multipart/form-data">
        <label>Wallpaper <input type="file" id="gwall" name="gwall"></label> 
        <br><br>
        <label>Poster <input type="file" id="gposter" name="gposter"></label> 
        <br><br>
        <img src="Icons/user-icon.png" class="sub-logo"><label><input type="text" id="gametitle" name="gametitle" placeholder="Game Title"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/user-icon.png" class="sub-logo"><label><input type="text" id="gameprice" name="gameprice" placeholder="Game price"></label>
        <div class="line-1"></div>
        <br><br>
        <div class="login-failed">
            <?php if($addgamefailed ==true){echo "Failed To Add Game";}?>
        </div>
        <br><br>
        <button type="submit" class="sign-up-submit"> Add Game</button>
     </form>
    </div>
 </body>
</head>
</html>

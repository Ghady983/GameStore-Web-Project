<?php require_once 'Includes/SignUp.inc.php' ?>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-reg-body">

<?php require_once "Reg-Log-Header.php"; ?> 


    <!-- Reg form -->
    <div class="reg-form">
    <h1>Register</h1>
    <div class="line-2"></div>
    <form action="#" method="post">
        
        <img src="Icons/user-icon.png" class="sub-logo"><label><input type="text" id="firstname" name="firstname" placeholder="First Name"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/user-icon.png" class="sub-logo"><label><input type="text" id="lastname" name="lastname" placeholder="Last name"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/mail-icon.png" class="sub-logo"><label><input type="email" id="email" name="email" placeholder="E-mail"></label>    
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/user-icon.png" class="sub-logo"><label><input type="text" id="username" name="username" placeholder="Username"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/key-icon.png" class="sub-logo"><label> <input type="password" id="password" name="password" placeholder="Password"></label>
        <div class="line-1"></div>
        <br><br>
        <img src="Icons/key-icon.png" class="sub-logo"><label> <input type="password" id="confirmpassword" name="confirmpassword" placeholder="Confirm Password"></label>
        <div class="line-1"></div>
        <br><br>
        <br><br>

        <div class="login-failed">
            
            <?php if($reg_failed ==true){echo "Registration Failed <br><br>";}?>
            <?php if($email_inuse ==true){echo "Email Already in Use <br><br>";}?>
            <?php if($username_inuse ==true){echo "Username Already in Use";}?>
        </div>
        <br><br>
        Already Have an Account? <a href="LogIn.php">Login</a>
        <br><br>
        <button type="submit" class="sign-up-submit"> Sign up </button>
     </form>
    </div>
 </body>
</head>
</html>


<!DOCTYPE html>
<html>
<head>
    <title>Failed To Purchase Game</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-reg-body">
<?php require_once "Reg-Log-Header.php"; ?>
<div class='fail_purchase'>
    <h1>Failed To Purchase Game</h1>    
</div>


 </body>
</head>
</html>

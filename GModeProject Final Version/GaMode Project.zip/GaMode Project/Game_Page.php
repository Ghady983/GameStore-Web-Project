<?php 
require_once 'Functions.php' ; 
require_once "Reg-Log-Header.php";
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if(isset($_GET["title"])){echo $_GET["title"];}else{echo "Title";}  ?></title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />

</head>

	<!-- CSS -->
    <style type="text/css"></style>
<body class="web-body">
<div class="header-cont" id="Home" >

	<div class="game-poster">
		<img src="GameWallpapers/<?php if(isset($_GET["poster"])){echo $_GET["poster"];}else{echo "base_wall.jpg";}  ?>">
	</div>

</div>
<div class='category-game-text'>
	<h3><?php checkCategoryForGame($_GET["id"]); ?></h3>
	<?php
	if(checkIsAdmin())
			{
				if(isset($_GET["id"]))
				{
				echo "<a href='Add_Categories.php?id=".$_GET["id"]."' class='add_category'></a>";
				}
			}
			?>
</div>
<div class='game-description'>
	<h1><?php if(isset($_GET["title"])){echo $_GET["title"];}else{echo "Title";}  ?></h1>
<span class='game-description-buy'>
	<?php  if(isset($_SESSION["account"]) && isset($_GET["price"]) && isset($_GET["id"]))
	{
		if(checkIfGameAlreadyInLibrary($_SESSION["account"][0],$_GET["id"])){echo"<div class='not_buy_game'>You Already Own this Game</div>";}
		else{
		if($_SESSION["account"]["Wallet"] >= $_GET["price"]){	
	?>
	<a href="BuyGame.php?gid=<?php echo $_GET["id"];?>" title='Buy Game'><h2>Buy</h2></a>
	<?php }
	else{echo"<div class='not_buy_game'>You need more money to buy this game</div>";}
	}
}
	else
	{
		echo"<div class='not_buy_game'>You need to be logged in to buy game</div>";	
	}
	
	?>
	<div class="space-div"></div>
	<h3>$<?php if(isset($_GET["price"])){echo $_GET["price"];}else{echo "price";}  ?></h3>
</span>	
</div>


    
</body>
</html>
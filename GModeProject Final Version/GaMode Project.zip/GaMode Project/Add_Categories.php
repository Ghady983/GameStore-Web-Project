<?php require_once 'Includes/Add_Categories.inc.php' ; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Categories</title>
    <link rel="stylesheet" type="text/css" href="CssFile.css" />
</head>

	<!-- CSS -->
    <style type="text/css"></style>

<body class="web-reg-body">

<?php require_once "Reg-Log-Header.php"; ?> 


    <!-- Reg form -->
    <div class="reg-form">
    <h1>Add Categories</h1>
    <div class="line-2"></div>
    <form action="#" method="GET" enctype="multipart/form-data">
<?php if(isset($_GET["id"])){echo "<input type='hidden' name='id' value='". $_GET["id"] ."'>";}?>    
    <input type='checkbox' title='Action' name="1" class='cat_checkbox'><input type='checkbox' title='Simulation' name="2" class='cat_checkbox'>
        <br><br>
    <input type='checkbox' title='Adventure' name="3" class='cat_checkbox'><input type='checkbox' title='OpenWorld' name="4" class='cat_checkbox'>
        <br><br>
        <div class="login-failed"> <?php if($already_exists ==true || $cat_already_exists != ""){echo "Already exist : &nbsp";} echo $cat_already_exists;?></div>
        <button type="submit" class="sign-up-submit"> Add Categories</button>
     </form>
    </div>
 </body>
</head>
</html>
